//
//  Bridging-Header.h
//  Chat
//
//  Created by Kanav Bhatia on 25/08/18.
//  Copyright © 2018 Kanav Bhatia. All rights reserved.
//

#ifndef Bridging_Header_h
#define Bridging_Header_h


#endif /* Bridging_Header_h */
#import <JSQMessagesViewController/JSQMessages.h>
