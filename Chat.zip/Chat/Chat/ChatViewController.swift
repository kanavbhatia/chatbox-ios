//
//  ViewController.swift
//  Chat
//
//  Created by Kanav Bhatia on 25/08/18.
//  Copyright © 2018 Kanav Bhatia. All rights reserved.
//

import UIKit
import JSQMessagesViewController

class ChatViewController: JSQMessagesViewController {
    
    var messages = [JSQMessage]()

    override func viewDidLoad() {
        super.viewDidLoad()
        let query = Constants.refs.databaseChats.queryLimited(toLast: 10)
        
        _ = query.observe(.childAdded, with: { [weak self] snapshot in
            
            if  let data        = snapshot.value as? [String: String],
                let id          = data["sender_id"],
                let name        = data["name"],
                let text        = data["text"],
                !text.isEmpty
            {
                if let message = JSQMessage(senderId: id, displayName: name, text: text)
                {
                    self?.messages.append(message)
                    
                    self?.finishReceivingMessage()
                }
            }
        })
        //Create a query to get the last 10 chat messages
        //Observe that query for newly added chat data, and call a closure when there’s new data
        //Inside the closure the data is “unpacked”, a new JSQMessage object is created, and added to the end of the messages array
       // The function finishReceivingMessage() is called, which prompts JSQMVC to refresh the UI and show the new message
        
        senderId = "9999096861"//numberText.text
        senderDisplayName = "Lagan"//nameText.text
        
        inputToolbar.contentView.leftBarButtonItem = nil
        collectionView.collectionViewLayout.incomingAvatarViewSize = CGSize.zero
        collectionView.collectionViewLayout.outgoingAvatarViewSize = CGSize.zero
        //The first line hides the attachment button on the left of the chat text input field. The other two lines of code set the avatar size to zero, again, hiding it. Check your progress with this screenshot
        
        func showDisplayNameDialog()
        {
            let defaults = UserDefaults.standard
            
            let alert = UIAlertController(title: "Your Display Name", message: "Before you can chat, please choose a display name. Others will see this name when you send chat messages. You can change your display name again by tapping the navigation bar.", preferredStyle: .alert)
            
            alert.addTextField { textField in
                
                if let name = defaults.string(forKey: "jsq_name")
                {
                    textField.text = name
                }
                else
                {
                    let names = ["Ford", "Arthur", "Zaphod", "Trillian", "Slartibartfast", "Humma Kavula", "Deep Thought"]
                    textField.text = names[Int(arc4random_uniform(UInt32(names.count)))]
                }
            }
            
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak self, weak alert] _ in
                
                if let textField = alert?.textFields?[0], !textField.text!.isEmpty {
                    
                    self?.senderDisplayName = textField.text
                    
                    self?.title = "Chat: \(self!.senderDisplayName!)"
                    
                    defaults.set(textField.text, forKey: "jsq_name")
                    defaults.synchronize()
                }
            }))
            
            present(alert, animated: true, completion: nil)
        }
    }
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, messageDataForItemAt indexPath: IndexPath!) -> JSQMessageData!
    {
        return messages[indexPath.item]
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return messages.count
    }
    lazy var outgoingBubble: JSQMessagesBubbleImage = {
        return JSQMessagesBubbleImageFactory()!.outgoingMessagesBubbleImage(with: UIColor.jsq_messageBubbleBlue())
    }() //for blue message
    
    lazy var incomingBubble: JSQMessagesBubbleImage = {
        return JSQMessagesBubbleImageFactory()!.incomingMessagesBubbleImage(with: UIColor.jsq_messageBubbleLightGray())
    }() // for grey message
    //You’ve just created two properties called outgoingBubble and incomingBubble, both of type JSQMessagesBubbleImage.
    //Both properties are computed properties. This means that they don’t have a fixed value, like 42, but a computed value: the result of a function.
    //Both properties are lazy, which means that they’re only initialized once – when they’re accessed. When you access a lazy property for the first time, its value is initialized (“created”). For every subsequent access, the value of the property isn’t recreated (as for typical computed properties), but simply returns the initial value.
    //In Swift, typical computed properties can’t be lazy! You’ve coded around that by creating a closure. The closure’s result is the value for the lazy property, effectively creating a lazy computed property.
    
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, messageBubbleImageDataForItemAt indexPath: IndexPath!) -> JSQMessageBubbleImageDataSource!
    {
        return messages[indexPath.item].senderId == senderId ? outgoingBubble : incomingBubble
    }
    //This function is yet another delegate, that’s called by JSQMVC when it needs bubble image data. Inside the function the ternary conditional operator a ? b : c is used to return the right bubble:
    //When messages[indexPath.item].senderId == senderId is true, return outgoingBubble, when that expression is false, return incomingBubble
    
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, avatarImageDataForItemAt indexPath: IndexPath!) -> JSQMessageAvatarImageDataSource!
    {
        return nil
    }
    //This function simply returns nil when JSQMVC wants avatar image data, effectively hiding the avatars
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, attributedTextForMessageBubbleTopLabelAt indexPath: IndexPath!) -> NSAttributedString!
    {
        return messages[indexPath.item].senderId == senderId ? nil : NSAttributedString(string: messages[indexPath.item].senderDisplayName)
    }
    //collectionView(_:attributedTextForMessageBubbleTopLabelAt:) is called when the label text is needed
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, layout collectionViewLayout: JSQMessagesCollectionViewFlowLayout!, heightForMessageBubbleTopLabelAt indexPath: IndexPath!) -> CGFloat
    {
        return messages[indexPath.item].senderId == senderId ? 0 : 15
    }
    //collectionView(_:collectionViewLayout:heightForMessageBubbleTopLabelAt:) is called when the height of the top label is needed
    
    override func didPressSend(_ button: UIButton!, withMessageText text: String!, senderId: String!, senderDisplayName: String!, date: Date!)
    {
        let ref = Constants.refs.databaseChats.childByAutoId()
        
        let message = ["sender_id": senderId, "name": senderDisplayName, "text": text]
        
        ref.setValue(message)
        
        finishSendingMessage()
    }
    //This function overrides a function on JSQMessagesViewController, the class you subclassed. This enables you to override what happens when a user presses the Send button, effectively creating your own implementation.
    

}

