//
//  WelcomeViewController.swift
//  Chat
//
//  Created by Kanav Bhatia on 28/08/18.
//  Copyright © 2018 Kanav Bhatia. All rights reserved.
//

import UIKit

class WelcomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var nameText: UITextField!
    
    @IBOutlet weak var numberText: UITextField!
    
    
    @IBAction func nextPage(_ sender: Any) {
        
        performSegue(withIdentifier: "goToSegue", sender: nil)
    }
    
    
}
