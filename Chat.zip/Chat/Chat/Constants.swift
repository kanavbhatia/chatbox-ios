//
//  Constants.swift
//  Chat
//
//  Created by Kanav Bhatia on 25/08/18.
//  Copyright © 2018 Kanav Bhatia. All rights reserved.
//

import Foundation
import Firebase

struct Constants
{
    struct refs
    {
        static let databaseRoot = Database.database().reference()
        static let databaseChats = databaseRoot.child("chats")
    }
}
